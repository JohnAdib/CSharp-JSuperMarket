﻿namespace JSuperMarket.frm_Products
{
    partial class frm_Products_Edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Products_Edit));
            this.lblFormTitle = new JSuperMarket.JSCLabel();
            this.jscUpdate1 = new JSuperMarket.JSCUpdate();
            this.jscClose1 = new JSuperMarket.JSCClose();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.jscLabel3 = new JSuperMarket.JSCLabel();
            this.jscTextBox7 = new JSuperMarket.JSCTextBox();
            this.jsBarCodeBox1 = new JSuperMarket.JSBarCodeBox();
            this.jscComboBox3 = new JSuperMarket.JSCComboBox();
            this.jscLabel13 = new JSuperMarket.JSCLabel();
            this.jscComboBox1 = new JSuperMarket.JSCComboBox();
            this.jscTextBox1 = new JSuperMarket.JSCTextBox();
            this.jscLabel9 = new JSuperMarket.JSCLabel();
            this.jscLabel2 = new JSuperMarket.JSCLabel();
            this.jscLabel1 = new JSuperMarket.JSCLabel();
            this.jscTextBox4 = new JSuperMarket.JSCTextBox();
            this.jscTextBox2 = new JSuperMarket.JSCTextBox();
            this.jscTextBox3 = new JSuperMarket.JSCTextBox();
            this.jscLabel4 = new JSuperMarket.JSCLabel();
            this.jscLabel5 = new JSuperMarket.JSCLabel();
            this.jscLabel6 = new JSuperMarket.JSCLabel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.jscTextBox10 = new JSuperMarket.JSCTextBox();
            this.jscLabel12 = new JSuperMarket.JSCLabel();
            this.jscTextBox8 = new JSuperMarket.JSCTextBox();
            this.jscLabel11 = new JSuperMarket.JSCLabel();
            this.jscLabel10 = new JSuperMarket.JSCLabel();
            this.jscTextBox5 = new JSuperMarket.JSCTextBox();
            this.jscLabel7 = new JSuperMarket.JSCLabel();
            this.jscLabel8 = new JSuperMarket.JSCLabel();
            this.jscTextBox6 = new JSuperMarket.JSCTextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblFormTitle
            // 
            this.lblFormTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFormTitle.AutoSize = true;
            this.lblFormTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblFormTitle.Font = new System.Drawing.Font("IranNastaliq", 15.75F);
            this.lblFormTitle.Location = new System.Drawing.Point(353, 366);
            this.lblFormTitle.Name = "lblFormTitle";
            this.lblFormTitle.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblFormTitle.Size = new System.Drawing.Size(73, 48);
            this.lblFormTitle.TabIndex = 31;
            this.lblFormTitle.Text = "ویرایش کالا";
            // 
            // jscUpdate1
            // 
            this.jscUpdate1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscUpdate1.BackColor = System.Drawing.Color.Transparent;
            this.jscUpdate1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jscUpdate1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.jscUpdate1.Image = ((System.Drawing.Image)(resources.GetObject("jscUpdate1.Image")));
            this.jscUpdate1.Location = new System.Drawing.Point(137, 377);
            this.jscUpdate1.Name = "jscUpdate1";
            this.jscUpdate1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscUpdate1.Size = new System.Drawing.Size(95, 35);
            this.jscUpdate1.TabIndex = 32;
            this.jscUpdate1.Text = "به روزرسانی";
            this.jscUpdate1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.jscUpdate1.UseVisualStyleBackColor = false;
            this.jscUpdate1.Click += new System.EventHandler(this.jscUpdate1_Click);
            // 
            // jscClose1
            // 
            this.jscClose1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscClose1.BackColor = System.Drawing.Color.Transparent;
            this.jscClose1.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.jscClose1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jscClose1.ForeColor = System.Drawing.Color.Black;
            this.jscClose1.Image = ((System.Drawing.Image)(resources.GetObject("jscClose1.Image")));
            this.jscClose1.Location = new System.Drawing.Point(12, 377);
            this.jscClose1.Name = "jscClose1";
            this.jscClose1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscClose1.Size = new System.Drawing.Size(95, 35);
            this.jscClose1.TabIndex = 33;
            this.jscClose1.Text = "بستن";
            this.jscClose1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.jscClose1.UseVisualStyleBackColor = false;
            this.jscClose1.Click += new System.EventHandler(this.jscClose1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.jscLabel3);
            this.groupBox1.Controls.Add(this.jscTextBox7);
            this.groupBox1.Controls.Add(this.jsBarCodeBox1);
            this.groupBox1.Controls.Add(this.jscComboBox3);
            this.groupBox1.Controls.Add(this.jscLabel13);
            this.groupBox1.Controls.Add(this.jscComboBox1);
            this.groupBox1.Controls.Add(this.jscTextBox1);
            this.groupBox1.Controls.Add(this.jscLabel9);
            this.groupBox1.Controls.Add(this.jscLabel2);
            this.groupBox1.Controls.Add(this.jscLabel1);
            this.groupBox1.Controls.Add(this.jscTextBox4);
            this.groupBox1.Controls.Add(this.jscTextBox2);
            this.groupBox1.Controls.Add(this.jscTextBox3);
            this.groupBox1.Controls.Add(this.jscLabel4);
            this.groupBox1.Controls.Add(this.jscLabel5);
            this.groupBox1.Controls.Add(this.jscLabel6);
            this.groupBox1.Location = new System.Drawing.Point(13, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(515, 178);
            this.groupBox1.TabIndex = 34;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "مشخصات اصلی کالا";
            // 
            // jscLabel3
            // 
            this.jscLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel3.AutoSize = true;
            this.jscLabel3.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel3.Location = new System.Drawing.Point(170, 138);
            this.jscLabel3.Name = "jscLabel3";
            this.jscLabel3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel3.Size = new System.Drawing.Size(37, 21);
            this.jscLabel3.TabIndex = 33;
            this.jscLabel3.Text = "محتوی\r\n";
            // 
            // jscTextBox7
            // 
            this.jscTextBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscTextBox7.Location = new System.Drawing.Point(13, 135);
            this.jscTextBox7.MaxLength = 200;
            this.jscTextBox7.Name = "jscTextBox7";
            this.jscTextBox7.Number = 0;
            this.jscTextBox7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscTextBox7.Size = new System.Drawing.Size(151, 28);
            this.jscTextBox7.TabIndex = 7;
            // 
            // jsBarCodeBox1
            // 
            this.jsBarCodeBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsBarCodeBox1.Enabled = false;
            this.jsBarCodeBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jsBarCodeBox1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.jsBarCodeBox1.Location = new System.Drawing.Point(236, 100);
            this.jsBarCodeBox1.Name = "jsBarCodeBox1";
            this.jsBarCodeBox1.ReadOnly = true;
            this.jsBarCodeBox1.Size = new System.Drawing.Size(200, 26);
            this.jsBarCodeBox1.TabIndex = 31;
            this.jsBarCodeBox1.TabStop = false;
            this.jsBarCodeBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jscComboBox3
            // 
            this.jscComboBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.jscComboBox3.FormattingEnabled = true;
            this.jscComboBox3.Items.AddRange(new object[] {
            "عدد"});
            this.jscComboBox3.Location = new System.Drawing.Point(236, 132);
            this.jscComboBox3.Name = "jscComboBox3";
            this.jscComboBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscComboBox3.Size = new System.Drawing.Size(200, 29);
            this.jscComboBox3.TabIndex = 6;
            // 
            // jscLabel13
            // 
            this.jscLabel13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel13.AutoSize = true;
            this.jscLabel13.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel13.Location = new System.Drawing.Point(442, 102);
            this.jscLabel13.Name = "jscLabel13";
            this.jscLabel13.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel13.Size = new System.Drawing.Size(31, 21);
            this.jscLabel13.TabIndex = 30;
            this.jscLabel13.Text = "بارکد";
            this.jscLabel13.Click += new System.EventHandler(this.jscLabel13_Click);
            // 
            // jscComboBox1
            // 
            this.jscComboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.jscComboBox1.FormattingEnabled = true;
            this.jscComboBox1.Location = new System.Drawing.Point(236, 65);
            this.jscComboBox1.Name = "jscComboBox1";
            this.jscComboBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscComboBox1.Size = new System.Drawing.Size(200, 29);
            this.jscComboBox1.TabIndex = 2;
            // 
            // jscTextBox1
            // 
            this.jscTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscTextBox1.Location = new System.Drawing.Point(236, 31);
            this.jscTextBox1.MaxLength = 200;
            this.jscTextBox1.Name = "jscTextBox1";
            this.jscTextBox1.Number = 0;
            this.jscTextBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscTextBox1.Size = new System.Drawing.Size(200, 28);
            this.jscTextBox1.TabIndex = 1;
            // 
            // jscLabel9
            // 
            this.jscLabel9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel9.AutoSize = true;
            this.jscLabel9.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel9.Location = new System.Drawing.Point(442, 135);
            this.jscLabel9.Name = "jscLabel9";
            this.jscLabel9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel9.Size = new System.Drawing.Size(46, 21);
            this.jscLabel9.TabIndex = 25;
            this.jscLabel9.Text = "واحد کالا";
            // 
            // jscLabel2
            // 
            this.jscLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel2.AutoSize = true;
            this.jscLabel2.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel2.Location = new System.Drawing.Point(442, 68);
            this.jscLabel2.Name = "jscLabel2";
            this.jscLabel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel2.Size = new System.Drawing.Size(63, 21);
            this.jscLabel2.TabIndex = 23;
            this.jscLabel2.Text = "دسته ی اصلی";
            // 
            // jscLabel1
            // 
            this.jscLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel1.AutoSize = true;
            this.jscLabel1.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel1.ForeColor = System.Drawing.Color.Red;
            this.jscLabel1.Location = new System.Drawing.Point(442, 34);
            this.jscLabel1.Name = "jscLabel1";
            this.jscLabel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel1.Size = new System.Drawing.Size(37, 21);
            this.jscLabel1.TabIndex = 22;
            this.jscLabel1.Text = "نام کالا";
            // 
            // jscTextBox4
            // 
            this.jscTextBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscTextBox4.Location = new System.Drawing.Point(13, 99);
            this.jscTextBox4.MaxLength = 200;
            this.jscTextBox4.Name = "jscTextBox4";
            this.jscTextBox4.Number = 0;
            this.jscTextBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscTextBox4.Size = new System.Drawing.Size(151, 28);
            this.jscTextBox4.TabIndex = 5;
            this.jscTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jscTextBox2
            // 
            this.jscTextBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscTextBox2.Location = new System.Drawing.Point(13, 31);
            this.jscTextBox2.MaxLength = 200;
            this.jscTextBox2.Name = "jscTextBox2";
            this.jscTextBox2.Number = 0;
            this.jscTextBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscTextBox2.Size = new System.Drawing.Size(151, 28);
            this.jscTextBox2.TabIndex = 3;
            this.jscTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jscTextBox3
            // 
            this.jscTextBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscTextBox3.Location = new System.Drawing.Point(13, 65);
            this.jscTextBox3.MaxLength = 200;
            this.jscTextBox3.Name = "jscTextBox3";
            this.jscTextBox3.Number = 0;
            this.jscTextBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscTextBox3.Size = new System.Drawing.Size(151, 28);
            this.jscTextBox3.TabIndex = 4;
            this.jscTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jscLabel4
            // 
            this.jscLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel4.AutoSize = true;
            this.jscLabel4.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel4.ForeColor = System.Drawing.Color.Red;
            this.jscLabel4.Location = new System.Drawing.Point(170, 34);
            this.jscLabel4.Name = "jscLabel4";
            this.jscLabel4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel4.Size = new System.Drawing.Size(60, 21);
            this.jscLabel4.TabIndex = 3;
            this.jscLabel4.Text = "قیمت فروش";
            // 
            // jscLabel5
            // 
            this.jscLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel5.AutoSize = true;
            this.jscLabel5.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel5.Location = new System.Drawing.Point(170, 68);
            this.jscLabel5.Name = "jscLabel5";
            this.jscLabel5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel5.Size = new System.Drawing.Size(37, 21);
            this.jscLabel5.TabIndex = 4;
            this.jscLabel5.Text = "تخفیف";
            // 
            // jscLabel6
            // 
            this.jscLabel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel6.AutoSize = true;
            this.jscLabel6.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel6.ForeColor = System.Drawing.Color.Red;
            this.jscLabel6.Location = new System.Drawing.Point(170, 102);
            this.jscLabel6.Name = "jscLabel6";
            this.jscLabel6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel6.Size = new System.Drawing.Size(55, 21);
            this.jscLabel6.TabIndex = 5;
            this.jscLabel6.Text = "قیمت خرید";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.maskedTextBox1);
            this.groupBox2.Controls.Add(this.jscTextBox10);
            this.groupBox2.Controls.Add(this.jscLabel12);
            this.groupBox2.Controls.Add(this.jscTextBox8);
            this.groupBox2.Controls.Add(this.jscLabel11);
            this.groupBox2.Controls.Add(this.jscLabel10);
            this.groupBox2.Controls.Add(this.jscTextBox5);
            this.groupBox2.Controls.Add(this.jscLabel7);
            this.groupBox2.Controls.Add(this.jscLabel8);
            this.groupBox2.Controls.Add(this.jscTextBox6);
            this.groupBox2.Location = new System.Drawing.Point(13, 196);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(515, 175);
            this.groupBox2.TabIndex = 35;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "سایر مشخصات";
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.maskedTextBox1.Culture = new System.Globalization.CultureInfo("fa-IR");
            this.maskedTextBox1.Enabled = false;
            this.maskedTextBox1.Location = new System.Drawing.Point(13, 61);
            this.maskedTextBox1.Mask = "00/00/0000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.ReadOnly = true;
            this.maskedTextBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.maskedTextBox1.Size = new System.Drawing.Size(151, 28);
            this.maskedTextBox1.TabIndex = 4;
            this.maskedTextBox1.ValidatingType = typeof(System.DateTime);
            // 
            // jscTextBox10
            // 
            this.jscTextBox10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscTextBox10.Location = new System.Drawing.Point(13, 104);
            this.jscTextBox10.MaxLength = 200;
            this.jscTextBox10.Multiline = true;
            this.jscTextBox10.Name = "jscTextBox10";
            this.jscTextBox10.Number = 0;
            this.jscTextBox10.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscTextBox10.Size = new System.Drawing.Size(423, 57);
            this.jscTextBox10.TabIndex = 5;
            // 
            // jscLabel12
            // 
            this.jscLabel12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel12.AutoSize = true;
            this.jscLabel12.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel12.Location = new System.Drawing.Point(442, 104);
            this.jscLabel12.Name = "jscLabel12";
            this.jscLabel12.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel12.Size = new System.Drawing.Size(36, 21);
            this.jscLabel12.TabIndex = 28;
            this.jscLabel12.Text = "توضیح";
            // 
            // jscTextBox8
            // 
            this.jscTextBox8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscTextBox8.Location = new System.Drawing.Point(13, 27);
            this.jscTextBox8.MaxLength = 200;
            this.jscTextBox8.Name = "jscTextBox8";
            this.jscTextBox8.Number = 0;
            this.jscTextBox8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscTextBox8.Size = new System.Drawing.Size(151, 28);
            this.jscTextBox8.TabIndex = 3;
            // 
            // jscLabel11
            // 
            this.jscLabel11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel11.AutoSize = true;
            this.jscLabel11.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel11.Location = new System.Drawing.Point(170, 64);
            this.jscLabel11.Name = "jscLabel11";
            this.jscLabel11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel11.Size = new System.Drawing.Size(53, 21);
            this.jscLabel11.TabIndex = 25;
            this.jscLabel11.Text = "تاریخ انقضا";
            // 
            // jscLabel10
            // 
            this.jscLabel10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel10.AutoSize = true;
            this.jscLabel10.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel10.Location = new System.Drawing.Point(170, 30);
            this.jscLabel10.Name = "jscLabel10";
            this.jscLabel10.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel10.Size = new System.Drawing.Size(69, 21);
            this.jscLabel10.TabIndex = 24;
            this.jscLabel10.Text = "کارخانه سازنده";
            // 
            // jscTextBox5
            // 
            this.jscTextBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscTextBox5.Location = new System.Drawing.Point(306, 36);
            this.jscTextBox5.MaxLength = 200;
            this.jscTextBox5.Name = "jscTextBox5";
            this.jscTextBox5.Number = 0;
            this.jscTextBox5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscTextBox5.Size = new System.Drawing.Size(130, 28);
            this.jscTextBox5.TabIndex = 1;
            // 
            // jscLabel7
            // 
            this.jscLabel7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel7.AutoSize = true;
            this.jscLabel7.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel7.Location = new System.Drawing.Point(442, 39);
            this.jscLabel7.Name = "jscLabel7";
            this.jscLabel7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel7.Size = new System.Drawing.Size(61, 21);
            this.jscLabel7.TabIndex = 6;
            this.jscLabel7.Text = "موجودی انبار";
            // 
            // jscLabel8
            // 
            this.jscLabel8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel8.AutoSize = true;
            this.jscLabel8.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel8.Location = new System.Drawing.Point(442, 73);
            this.jscLabel8.Name = "jscLabel8";
            this.jscLabel8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel8.Size = new System.Drawing.Size(70, 21);
            this.jscLabel8.TabIndex = 7;
            this.jscLabel8.Text = "حداقل موجودی";
            // 
            // jscTextBox6
            // 
            this.jscTextBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscTextBox6.Location = new System.Drawing.Point(306, 70);
            this.jscTextBox6.MaxLength = 200;
            this.jscTextBox6.Name = "jscTextBox6";
            this.jscTextBox6.Number = 1;
            this.jscTextBox6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscTextBox6.Size = new System.Drawing.Size(130, 28);
            this.jscTextBox6.TabIndex = 2;
            // 
            // frm_Products_Edit
            // 
            this.AcceptButton = this.jscUpdate1;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 21F);
            this.CancelButton = this.jscClose1;
            this.ClientSize = new System.Drawing.Size(540, 421);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.jscClose1);
            this.Controls.Add(this.jscUpdate1);
            this.Controls.Add(this.lblFormTitle);
            this.KeyPreview = true;
            this.Name = "frm_Products_Edit";
            this.Load += new System.EventHandler(this.frm_Products_Edit_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.frm_Products_Edit_KeyPress);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private JSCLabel lblFormTitle;
        private JSCUpdate jscUpdate1;
        private JSCClose jscClose1;
        private System.Windows.Forms.GroupBox groupBox1;
        private JSCLabel jscLabel3;
        private JSCTextBox jscTextBox7;
        private JSBarCodeBox jsBarCodeBox1;
        private JSCComboBox jscComboBox3;
        private JSCLabel jscLabel13;
        private JSCComboBox jscComboBox1;
        private JSCTextBox jscTextBox1;
        private JSCLabel jscLabel9;
        private JSCLabel jscLabel2;
        private JSCLabel jscLabel1;
        private JSCTextBox jscTextBox4;
        private JSCTextBox jscTextBox2;
        private JSCTextBox jscTextBox3;
        private JSCLabel jscLabel4;
        private JSCLabel jscLabel5;
        private JSCLabel jscLabel6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private JSCTextBox jscTextBox10;
        private JSCLabel jscLabel12;
        private JSCTextBox jscTextBox8;
        private JSCLabel jscLabel11;
        private JSCLabel jscLabel10;
        private JSCTextBox jscTextBox5;
        private JSCLabel jscLabel7;
        private JSCLabel jscLabel8;
        private JSCTextBox jscTextBox6;
    }
}
