﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace JSuperMarket
{
    public partial class test1 : frm_base_ShowData
    {
        public test1()
        {

            InitializeComponent();
        }


    }
}
