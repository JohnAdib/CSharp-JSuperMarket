﻿namespace JSuperMarket.frm_Customers
{
    partial class frm_Customers_Edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Customers_Edit));
            this.lblFormTitle = new JSuperMarket.JSCLabel();
            this.jscTextBox5 = new JSuperMarket.JSCTextBox();
            this.jscTextBox4 = new JSuperMarket.JSCTextBox();
            this.jscTextBox3 = new JSuperMarket.JSCTextBox();
            this.jscTextBox2 = new JSuperMarket.JSCTextBox();
            this.jscTextBox1 = new JSuperMarket.JSCTextBox();
            this.jscLabel5 = new JSuperMarket.JSCLabel();
            this.jscLabel4 = new JSuperMarket.JSCLabel();
            this.jscLabel3 = new JSuperMarket.JSCLabel();
            this.jscLabel2 = new JSuperMarket.JSCLabel();
            this.jscLabel1 = new JSuperMarket.JSCLabel();
            this.jscUpdate1 = new JSuperMarket.JSCUpdate();
            this.jscClose1 = new JSuperMarket.JSCClose();
            this.jscCheckBox1 = new JSuperMarket.JSCCheckBox();
            this.SuspendLayout();
            // 
            // lblFormTitle
            // 
            this.lblFormTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFormTitle.AutoSize = true;
            this.lblFormTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblFormTitle.Font = new System.Drawing.Font("IranNastaliq", 15.75F);
            this.lblFormTitle.Location = new System.Drawing.Point(61, 9);
            this.lblFormTitle.Name = "lblFormTitle";
            this.lblFormTitle.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblFormTitle.Size = new System.Drawing.Size(93, 48);
            this.lblFormTitle.TabIndex = 33;
            this.lblFormTitle.Text = "ویرایش مشتری";
            // 
            // jscTextBox5
            // 
            this.jscTextBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscTextBox5.Location = new System.Drawing.Point(15, 242);
            this.jscTextBox5.Multiline = true;
            this.jscTextBox5.Name = "jscTextBox5";
            this.jscTextBox5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscTextBox5.Size = new System.Drawing.Size(150, 62);
            this.jscTextBox5.TabIndex = 32;
            // 
            // jscTextBox4
            // 
            this.jscTextBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscTextBox4.Location = new System.Drawing.Point(15, 208);
            this.jscTextBox4.Name = "jscTextBox4";
            this.jscTextBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscTextBox4.Size = new System.Drawing.Size(150, 28);
            this.jscTextBox4.TabIndex = 31;
            // 
            // jscTextBox3
            // 
            this.jscTextBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscTextBox3.Location = new System.Drawing.Point(15, 174);
            this.jscTextBox3.Name = "jscTextBox3";
            this.jscTextBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscTextBox3.Size = new System.Drawing.Size(150, 28);
            this.jscTextBox3.TabIndex = 30;
            // 
            // jscTextBox2
            // 
            this.jscTextBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscTextBox2.Location = new System.Drawing.Point(15, 106);
            this.jscTextBox2.Multiline = true;
            this.jscTextBox2.Name = "jscTextBox2";
            this.jscTextBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscTextBox2.Size = new System.Drawing.Size(150, 62);
            this.jscTextBox2.TabIndex = 29;
            // 
            // jscTextBox1
            // 
            this.jscTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscTextBox1.Location = new System.Drawing.Point(15, 72);
            this.jscTextBox1.Name = "jscTextBox1";
            this.jscTextBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscTextBox1.Size = new System.Drawing.Size(150, 28);
            this.jscTextBox1.TabIndex = 28;
            // 
            // jscLabel5
            // 
            this.jscLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel5.AutoSize = true;
            this.jscLabel5.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel5.Location = new System.Drawing.Point(171, 245);
            this.jscLabel5.Name = "jscLabel5";
            this.jscLabel5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel5.Size = new System.Drawing.Size(36, 21);
            this.jscLabel5.TabIndex = 27;
            this.jscLabel5.Text = "توضیح";
            // 
            // jscLabel4
            // 
            this.jscLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel4.AutoSize = true;
            this.jscLabel4.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel4.Location = new System.Drawing.Point(171, 211);
            this.jscLabel4.Name = "jscLabel4";
            this.jscLabel4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel4.Size = new System.Drawing.Size(34, 21);
            this.jscLabel4.TabIndex = 26;
            this.jscLabel4.Text = "موبایل";
            // 
            // jscLabel3
            // 
            this.jscLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel3.AutoSize = true;
            this.jscLabel3.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel3.Location = new System.Drawing.Point(171, 177);
            this.jscLabel3.Name = "jscLabel3";
            this.jscLabel3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel3.Size = new System.Drawing.Size(28, 21);
            this.jscLabel3.TabIndex = 25;
            this.jscLabel3.Text = "تلفن";
            // 
            // jscLabel2
            // 
            this.jscLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel2.AutoSize = true;
            this.jscLabel2.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel2.Location = new System.Drawing.Point(171, 109);
            this.jscLabel2.Name = "jscLabel2";
            this.jscLabel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel2.Size = new System.Drawing.Size(37, 21);
            this.jscLabel2.TabIndex = 24;
            this.jscLabel2.Text = "آدرس";
            // 
            // jscLabel1
            // 
            this.jscLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscLabel1.AutoSize = true;
            this.jscLabel1.BackColor = System.Drawing.Color.Transparent;
            this.jscLabel1.Location = new System.Drawing.Point(171, 75);
            this.jscLabel1.Name = "jscLabel1";
            this.jscLabel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscLabel1.Size = new System.Drawing.Size(52, 21);
            this.jscLabel1.TabIndex = 23;
            this.jscLabel1.Text = "نام مشتری";
            // 
            // jscUpdate1
            // 
            this.jscUpdate1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscUpdate1.BackColor = System.Drawing.Color.Transparent;
            this.jscUpdate1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jscUpdate1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.jscUpdate1.Image = ((System.Drawing.Image)(resources.GetObject("jscUpdate1.Image")));
            this.jscUpdate1.Location = new System.Drawing.Point(116, 311);
            this.jscUpdate1.Name = "jscUpdate1";
            this.jscUpdate1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscUpdate1.Size = new System.Drawing.Size(95, 35);
            this.jscUpdate1.TabIndex = 34;
            this.jscUpdate1.Text = "به روزرسانی";
            this.jscUpdate1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.jscUpdate1.UseVisualStyleBackColor = false;
            this.jscUpdate1.Click += new System.EventHandler(this.jscUpdate1_Click);
            // 
            // jscClose1
            // 
            this.jscClose1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscClose1.BackColor = System.Drawing.Color.Transparent;
            this.jscClose1.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.jscClose1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jscClose1.ForeColor = System.Drawing.Color.Black;
            this.jscClose1.Image = ((System.Drawing.Image)(resources.GetObject("jscClose1.Image")));
            this.jscClose1.Location = new System.Drawing.Point(15, 311);
            this.jscClose1.Name = "jscClose1";
            this.jscClose1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscClose1.Size = new System.Drawing.Size(95, 35);
            this.jscClose1.TabIndex = 35;
            this.jscClose1.Text = "بستن";
            this.jscClose1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.jscClose1.UseVisualStyleBackColor = false;
            this.jscClose1.Click += new System.EventHandler(this.jscClose1_Click);
            // 
            // jscCheckBox1
            // 
            this.jscCheckBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscCheckBox1.Appearance = System.Windows.Forms.Appearance.Button;
            this.jscCheckBox1.AutoSize = true;
            this.jscCheckBox1.Location = new System.Drawing.Point(15, 274);
            this.jscCheckBox1.Name = "jscCheckBox1";
            this.jscCheckBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscCheckBox1.Size = new System.Drawing.Size(75, 31);
            this.jscCheckBox1.TabIndex = 36;
            this.jscCheckBox1.Text = "حساب دفتری";
            this.jscCheckBox1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.jscCheckBox1.UseVisualStyleBackColor = true;
            // 
            // frm_Customers_Edit
            // 
            this.AcceptButton = this.jscUpdate1;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 21F);
            this.CancelButton = this.jscClose1;
            this.ClientSize = new System.Drawing.Size(235, 367);
            this.Controls.Add(this.jscCheckBox1);
            this.Controls.Add(this.jscClose1);
            this.Controls.Add(this.jscUpdate1);
            this.Controls.Add(this.lblFormTitle);
            this.Controls.Add(this.jscTextBox5);
            this.Controls.Add(this.jscTextBox4);
            this.Controls.Add(this.jscTextBox3);
            this.Controls.Add(this.jscTextBox2);
            this.Controls.Add(this.jscTextBox1);
            this.Controls.Add(this.jscLabel5);
            this.Controls.Add(this.jscLabel4);
            this.Controls.Add(this.jscLabel3);
            this.Controls.Add(this.jscLabel2);
            this.Controls.Add(this.jscLabel1);
            this.Name = "frm_Customers_Edit";
            this.Load += new System.EventHandler(this.frm_Customers_Edit_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private JSCLabel lblFormTitle;
        private JSCTextBox jscTextBox5;
        private JSCTextBox jscTextBox4;
        private JSCTextBox jscTextBox3;
        private JSCTextBox jscTextBox2;
        private JSCTextBox jscTextBox1;
        private JSCLabel jscLabel5;
        private JSCLabel jscLabel4;
        private JSCLabel jscLabel3;
        private JSCLabel jscLabel2;
        private JSCLabel jscLabel1;
        private JSCUpdate jscUpdate1;
        private JSCClose jscClose1;
        private JSCCheckBox jscCheckBox1;
    }
}
